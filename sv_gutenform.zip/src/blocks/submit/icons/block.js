export default (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M14 9l10 7.675-4.236.71 2.66 5.423-2.441 1.192-2.675-5.474-3.308 2.863v-12.389zm-7-7h5v-2h-5v2zm7 0h3v3h2v-5h-5v2zm-12 3v-3h3v-2h-5v5h2zm-2 7h2v-5h-2v5zm5 5h-3v-3h-2v5h5v-2zm12-10v1.781l2 1.535v-3.316h-2zm-10 12h5v-2h-5v2z"/></svg>
);