<div class="<?php echo $this->get_wrapper_class(); ?>">
    <button <?php echo $this->get_button_attr(); ?>>
        <?php echo $attr['content']; ?>
    </a>
</div>