<div class="wp-block-straightvisions-sv-gutenform-thank-you" style="display: none;">
    <?php echo $content; ?>
</div>