<div class="<?php echo $this->get_wrapper_class(); ?>">
    <?php echo $this->get_options(); ?>
</div>