<div class="<?php echo $this->get_wrapper_class(); ?>">
    <?php echo $content; ?>
</div>