# component_sv_color_picker_min
Contact Person: Adrian Chudzynski
