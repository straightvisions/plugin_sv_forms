		<div class="sv_admin_notice"></div>
		<div class="sv_admin_modal">
			<div class="sv_admin_modal_header">
				<h3 class="sv_admin_modal_title"></h3>
				<i class="sv_admin_modal_close"></i>
			</div>
			<p class="sv_admin_modal_description"></p>
			<div class="sv_admin_modal_body">
				<div class="sv_admin_modal_content"></div>
				<button class="sv_admin_modal_cancel sv_dashboard_button"><?php _e( 'Cancel', 'sv100' ); ?></button>
			</div>
		</div>
	</div> <!-- END sv_dashboard_content -->
</div> <!-- END sv_wrapper -->