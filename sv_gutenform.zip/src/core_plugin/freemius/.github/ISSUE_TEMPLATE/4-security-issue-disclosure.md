---
name: ⚠️ Security issue disclosure
about: Report a security issue in Freemius SDK, API, Developer Dashboard, or User Dashboard

---

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑

To report vulnerabilities in Freemius itself, email us at security@freemius.com.

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑