---
name: "❓ Support request"
about: Questions and requests for support

---

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑

Please do not file questions or support requests on the GitHub issues tracker.

You can get your questions answered by contacting our support team via support@freemius.com

Thank you!

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑